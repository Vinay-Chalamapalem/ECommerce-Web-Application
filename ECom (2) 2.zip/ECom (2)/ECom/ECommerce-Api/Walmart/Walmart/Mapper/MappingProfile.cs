﻿using AutoMapper;
using Walmart.Models.Domain;
using Walmart.Models.DTO;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // 🚀 CartItem Mappings
        CreateMap<CartItem, CartItemDTO>().ReverseMap();
        CreateMap<CartItem, CartItemResponseDTO>().ReverseMap();
        CreateMap<CartItem, CartItemDetailsDTO>().ReverseMap();

        // OrderItem Mappings
        CreateMap<OrderItem, CartItemDetailsDTO>().ReverseMap();
        CreateMap<OrderItem, OrderManagementDTO>().ReverseMap();

        // OrderManagement Mappings
        CreateMap<OrderManagement, OrderManagementDTO>().ReverseMap();
        CreateMap<OrderManagement, Checkout>().ReverseMap();
        CreateMap<OrderManagement, OrderManagedto>().ReverseMap();
        CreateMap<OrderManagement, ordernowdto>().ReverseMap();

        // 🚀 Product Management Mappings
        CreateMap<ProductManagement, ProductManagementDTO>().ReverseMap();

        // 🚀 User Mappings
        CreateMap<User, UserDTO>().ReverseMap();
        CreateMap<User, RegisterDTO>().ReverseMap();
        CreateMap<User, LoginDTO>().ReverseMap();
        CreateMap<User, FilteredUserDTO>().ReverseMap();

        // 🚀 Admin Mappings
        CreateMap<Admin, AnalyticsDTO>().ReverseMap();
        CreateMap<RegisterDTO, Admin>().ReverseMap();
        CreateMap<Admin, AdminDto>().ReverseMap();
        CreateMap<ProductAdminDto, ProductManagement>().ReverseMap();
        CreateMap<UserAdminDto, User>().ReverseMap();
    }
}
