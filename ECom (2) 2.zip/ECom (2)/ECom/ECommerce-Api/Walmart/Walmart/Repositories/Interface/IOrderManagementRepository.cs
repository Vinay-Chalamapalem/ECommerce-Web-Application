﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;

namespace Walmart.Repositories.Interface
{
    public interface IOrderManagementRepository
    {
        Task<IEnumerable<OrderManagement>> GetAllOrdersAsync();
        Task<OrderManagement> GetOrderByIdAsync(int id);
        Task<ProductManagement> GetProductByIdAsync(int id);
        Task<User> GetUserByIdAsync(int id);
        Task AddOrderAsync(OrderManagement order);
        Task UpdateOrderAsync(OrderManagement order);
        Task DeleteOrderAsync(int id);
    }
}