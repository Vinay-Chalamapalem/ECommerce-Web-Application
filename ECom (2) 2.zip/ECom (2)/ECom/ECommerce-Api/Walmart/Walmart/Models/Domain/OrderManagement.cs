﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Walmart.Models.Domain
{
    public class OrderManagement
    {
        [Key]
        public int OrderID { get; set; }
        [ForeignKey("User")]
        public int UserID { get; set; }
        [ForeignKey("ProductManagement")]
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ShippingAddress { get; set; } = string.Empty;
        public string OrderStatus { get; set; } = string.Empty;
        public string PaymentStatus { get; set; } = string.Empty;
 
 
        public string ProductName { get; set; } = string.Empty; // Product name
        public string ImageURL { get; set; } = string.Empty;
 
 
        public ProductManagement ProductManagement { get; set; } = new ProductManagement();
        public User User { get; set; } = new User();
        public List<OrderItem> OrderItems { get; set; }
    }
}