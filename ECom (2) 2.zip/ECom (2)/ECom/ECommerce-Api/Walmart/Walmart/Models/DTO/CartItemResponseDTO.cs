﻿namespace Walmart.Models.DTO
{
    public class CartItemResponseDTO
    {
        public int CartItemID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ImageURL { get; set; } // ✅ Includes image URL in API response
    }

    public class CartItemDetailsDTO
    {
        public int CartItemID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public string ImageURL { get; set; }
        public string ProductName { get; set; } // ✅ Added missing ProductName property
    }

}
