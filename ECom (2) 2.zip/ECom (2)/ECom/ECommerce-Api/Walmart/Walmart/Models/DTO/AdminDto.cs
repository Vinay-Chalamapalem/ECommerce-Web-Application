﻿namespace Walmart.Models.DTO
{
    public class AdminDto
    {

        public int AdminID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

    }

    public class ProductAdminDto
    {
        public int ProductId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string Category { get; set; } = string.Empty;
        public string ImageURL { get; set; } = string.Empty;
    }
    public class UserAdminDto
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string ShippingAddress { get; set; }
        public string PaymentDetails { get; set; }
    }
    public class OrderAdminDto
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }

        public string OrderStatus { get; set; }
    }



}