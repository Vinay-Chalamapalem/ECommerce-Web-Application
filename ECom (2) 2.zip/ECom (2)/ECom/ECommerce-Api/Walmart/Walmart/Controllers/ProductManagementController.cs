﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductManagementController : ControllerBase
    {
        private readonly IProductManagementRepository _productManagementRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<ProductManagementController> _logger;

        public ProductManagementController(IProductManagementRepository productManagementRepository, IMapper mapper, ILogger<ProductManagementController> logger)
        {
            _productManagementRepository = productManagementRepository;
            _mapper = mapper;
            _logger = logger;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("Add_Products")]
        public async Task<IActionResult> Create([FromBody] ProductManagementDTO productManagementRequest)
        {
            try
            {
                var newProduct = _mapper.Map<ProductManagement>(productManagementRequest);

                await _productManagementRepository.AddProductAsync(newProduct);

                var productResponse = _mapper.Map<ProductAdminDto>(newProduct);

                return CreatedAtAction(nameof(GetById), new { id = newProduct.ProductId }, productResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding a new product.");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("Search_By_Category")]
        public async Task<IActionResult> GetByCategory(string category)
        {
            try
            {
                var products = await _productManagementRepository.GetProductsByCategoryAsync(category);
                products = products.Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
                if (!products.Any())
                {
                    return NotFound($"No products found in the '{category}' category.");
                }

                var productDTOs = _mapper.Map<IEnumerable<ProductManagementDTO>>(products);
                return Ok(productDTOs);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching products by category {Category}.", category);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("Search_By_Name")]
        public async Task<IActionResult> GetByName(string Name)
        {
            try
            {
                var products = await _productManagementRepository.GetAllProductsAsync();
                var filteredProducts = products.Where(p => p.Name.Contains(Name, StringComparison.OrdinalIgnoreCase)).ToList();

                if (!filteredProducts.Any())
                {
                    return NotFound($"No products found containing '{Name}' in the name.");
                }

                var productDTOs = _mapper.Map<IEnumerable<ProductManagementDTO>>(filteredProducts);
                return Ok(productDTOs);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the product by name {ProductName}.", Name);
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet("Search_The_Product")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest("Invalid product ID.");
                }

                var product = await _productManagementRepository.GetProductByIdAsync(id);

                if (product == null)
                {
                    _logger.LogWarning("Product with ID {ProductID} not found.", id);
                    return NotFound($"Product with ID {id} not found.");
                }

                var productDTO = _mapper.Map<ProductManagementDTO>(product);
                return Ok(productDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching the product by ID {ProductID}.", id);
                return StatusCode(500, "Internal server error. Please try again later.");
            }
        }

        [HttpGet("All_Products")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var products = await _productManagementRepository.GetAllProductsAsync();

                if (products == null || !products.Any())
                    return NotFound("No products available.");

                var productDTOs = _mapper.Map<IEnumerable<ProductManagementDTO>>(products);

                return Ok(productDTOs); // ✅ Ensure ProductId is included
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching all products.");
                return StatusCode(500, "Internal server error");
            }
        }

        [Authorize(Roles = "Admin")]

        [HttpPatch("Edit_Product/{id}")]

        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] ProductManagementDTO productManagementRequest)

        {

            try

            {

                var existingProduct = await _productManagementRepository.GetProductByIdAsync(id);

                if (existingProduct == null)

                {

                    return NotFound($"Product with ID {id} not found.");

                }

                _mapper.Map(productManagementRequest, existingProduct);

                await _productManagementRepository.UpdateProductAsync(existingProduct);

                return Ok(existingProduct);

            }

            catch (Exception ex)

            {

                _logger.LogError(ex, "An error occurred while updating the product with ID {ProductID}.", id);

                return StatusCode(500, "Internal server error");

            }

        }

        [Authorize(Roles = "Admin")]

        [HttpDelete("Delete_Product/{id}")]

        public async Task<IActionResult> Delete([FromRoute] int id)

        {

            try

            {

                var product = await _productManagementRepository.GetProductByIdAsync(id);

                if (product == null)

                {

                    return NotFound($"Product with ID {id} not found.");

                }

                await _productManagementRepository.DeleteProductAsync(id);

                return Ok("Deleted Successfully!");

            }

            catch (Exception ex)

            {

                _logger.LogError(ex, "An error occurred while deleting the product with ID {ProductID}.", id);

                return StatusCode(500, "Internal server error");

            }

        }

    }
}
