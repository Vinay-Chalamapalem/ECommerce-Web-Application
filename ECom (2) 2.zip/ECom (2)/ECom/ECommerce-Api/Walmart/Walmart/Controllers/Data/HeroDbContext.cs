﻿using Microsoft.EntityFrameworkCore;
using Walmart.Models.Domain;

namespace Walmart.Data
{
    public class HeroDbContext : DbContext
    {
        public HeroDbContext(DbContextOptions<HeroDbContext> options) : base(options) { }

        public DbSet<ProductManagement> ProductManagements { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<OrderManagement> OrderManagements { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Admin> Admins { get; set; }
    }
}
