﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Walmart.Models.Domain;
using Walmart.Models.DTO;
using Walmart.Repositories.Interface;
using Microsoft.Extensions.Logging;
using System.Security.Claims;

namespace Walmart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderManagementController : ControllerBase
    {
        private readonly IOrderManagementRepository _orderManagementRepository;
        private readonly IUserRepository _userRepository;
        private readonly IProductManagementRepository _productManagementRepository;
        private readonly ICartItemRepository _cartItemRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<OrderManagementController> _logger;
        public OrderManagementController(
            IOrderManagementRepository orderManagementRepository,
            IUserRepository userRepository,
            IProductManagementRepository productManagementRepository,
            ICartItemRepository cartItemRepository,
            IMapper mapper,
            ILogger<OrderManagementController> logger)
        {
            _orderManagementRepository = orderManagementRepository;
            _userRepository = userRepository;
            _productManagementRepository = productManagementRepository;
            _cartItemRepository = cartItemRepository;
            _mapper = mapper;
            _logger = logger;
        }


        [HttpPost("OrderNow")]
        public async Task<IActionResult> Post([FromBody] ordernowdto orderRequest)
        {
            try
            {
                // Extract user ID from claims
                var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
                Console.WriteLine(userIdClaim);
                if (userIdClaim == null)
                {
                    return Unauthorized("User ID not found in claims.");
                }
                var userId = int.Parse(userIdClaim.Value);
                // Fetch product details
                var product = await _orderManagementRepository.GetProductByIdAsync(orderRequest.ProductID);
                if (product == null)
                {
                    return NotFound($"Product with ID {orderRequest.ProductID} not found.");
                }
                // Fetch user details
                var user = await _orderManagementRepository.GetUserByIdAsync(userId);
                if (user == null)
                {
                    return NotFound($"User with ID {userId} not found.");
                }
                // Map and compute order details
                var order = _mapper.Map<OrderManagement>(orderRequest);
                order.UserID = userId; // Set user ID
                order.TotalPrice = orderRequest.Quantity * product.Price; // Compute total price
                order.OrderStatus = "Placed"; // Set order status
                order.ProductManagement = product;
                order.User = user;
                order.ProductName = product.Name; // Set product name
                order.ImageURL = product.ImageURL; // Set product image URL
                // Add order to repository
                await _orderManagementRepository.AddOrderAsync(order);
                // Map response
                var orderResponse = _mapper.Map<OrderManagementDTO>(order);
                return CreatedAtAction(nameof(GetOrder), new { id = order.OrderID }, orderResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while placing an order.");
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPost("CheckoutFromCart")]
        public async Task<IActionResult> CheckoutCart([FromBody] Checkout checkoutRequest)
        {
            try
            {
                var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (userIdString == null)
                {
                    return Unauthorized("User not authenticated.");
                }

                if (!int.TryParse(userIdString, out int userId))
                {
                    return BadRequest("Invalid user ID.");
                }

                var cartItems = await _cartItemRepository.GetCartItemsByUserIdAsync(userId);
                if (cartItems == null || !cartItems.Any())
                {
                    return NotFound("No items in the cart.");
                }

                var orders = new List<OrderManagement>();

                foreach (var cartItem in cartItems)
                {
                    var product = await _cartItemRepository.GetProductByIdAsync(cartItem.ProductID);
                    if (product == null)
                    {
                        return NotFound($"Product with ID {cartItem.ProductID} not found.");
                    }

                    var totalPrice = cartItem.Quantity * product.Price;
                    var order = new OrderManagement
                    {
                        UserID = cartItem.UserID,
                        ProductID = cartItem.ProductID,
                        Quantity = cartItem.Quantity,
                        TotalPrice = totalPrice,
                        ShippingAddress = checkoutRequest.ShippingAddress,
                        OrderStatus = "Placed",
                        PaymentStatus = checkoutRequest.PaymentMode,
                        ProductManagement = product,
                        User = await _cartItemRepository.GetUserByIdAsync(cartItem.UserID),
                        ProductName = product.Name,
                        ImageURL = product.ImageURL
                    };

                    await _orderManagementRepository.AddOrderAsync(order);
                    await _cartItemRepository.DeleteCartItemAsync(cartItem.CartItemID);
                    orders.Add(order);
                }

                var orderResponses = _mapper.Map<List<OrderManagementDTO>>(orders);
                return CreatedAtAction(nameof(GetOrder), new { id = orders.First().OrderID }, orderResponses);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during checkout from cart.");
                return StatusCode(500, "Internal server error");
            }
        }




        [HttpGet("Your_Orders")]
        public async Task<IActionResult> GetOrdersByUserId()
        {
            try
            {
                // Get the current user's ID from the claims
                var currentUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (currentUserId == null)
                {
                    return Unauthorized("User ID not found.");
                }
                var userId = int.Parse(currentUserId);
                var orders = await _orderManagementRepository.GetAllOrdersAsync();
                var userOrders = orders.Where(o => o.UserID == userId).ToList();
                if (!userOrders.Any())
                {
                    return NotFound($"No orders found for User ID {userId}.");
                }
                var orderDTOs = _mapper.Map<IEnumerable<OrderManagementDTO>>(userOrders);
                return Ok(orderDTOs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }



        [HttpGet("Order_Details")]
        public async Task<ActionResult<OrderManagementDTO>> GetOrder(int id)
        {
            try
            {
                var order = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }
                var orderDTO = _mapper.Map<OrderManagementDTO>(order);
                return Ok(orderDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving order details for Order ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPut("Edit_Order/{id}")]
        public async Task<IActionResult> UpdateOrderStatus([FromRoute] int id, [FromBody] UpdateOrderDTO orderRequest)
        {
            try
            {
                var existingOrder = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (existingOrder == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }
                var product = await _productManagementRepository.GetProductByIdAsync(existingOrder.ProductID);
                if (product == null)
                {
                    return NotFound($"Product with ID {existingOrder.ProductID} not found.");
                }
                existingOrder.Quantity = orderRequest.Quantity;
                existingOrder.OrderStatus = orderRequest.OrderStatus;
                existingOrder.TotalPrice = orderRequest.Quantity * product.Price;

                await _orderManagementRepository.UpdateOrderAsync(existingOrder);
                return Ok(existingOrder);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating the order status for Order ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpDelete("Delete_the_Order")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            try
            {
                var order = await _orderManagementRepository.GetOrderByIdAsync(id);
                if (order == null)
                {
                    return NotFound($"Order with ID {id} not found.");
                }
                await _orderManagementRepository.DeleteOrderAsync(id);
                return Ok("Deleted Successfully!");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the order with ID {OrderID}.", id);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}